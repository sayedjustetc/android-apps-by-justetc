package com.salearningschool.bangla.html;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;
import android.webkit.WebView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private TextView mTextMessage;
    private WebView mWebView;

    private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
            = new BottomNavigationView.OnNavigationItemSelectedListener() {

        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            switch (item.getItemId()) {
                case R.id.navigation_home:
                    mTextMessage.setText(R.string.title_home);
                    return true;
                case R.id.navigation_dashboard:
                    mTextMessage.setText(R.string.title_dashboard);
                    return true;
                case R.id.navigation_notifications:
                    mTextMessage.setText(R.string.title_notifications);
                    return true;
            }
            return false;
        }

    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mWebView = (WebView) findViewById(R.id.activity_main_webview);
        //mWebView.setWebViewClient(new WebViewClient());

        mTextMessage = (TextView) findViewById(R.id.message);
        BottomNavigationView navigation = (BottomNavigationView) findViewById(R.id.navigation);
        navigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);

        mWebView.loadUrl("http://bangla.salearningschool.com/recent-posts/%E0%A6%8F%E0%A6%87%E0%A6%9A-%E0%A6%9F%E0%A6%BF-%E0%A6%8F%E0%A6%AE-%E0%A6%8F%E0%A6%B2-%E0%A6%95%E0%A7%8B%E0%A6%B0%E0%A7%8D%E0%A6%B8-%E0%A6%B8%E0%A6%AE%E0%A7%82%E0%A6%B9-%E0%A5%A4-html-courses");
        //http://bangla.salearningschool.com/recent-posts/%E0%A6%8F%E0%A6%87%E0%A6%9A-%E0%A6%9F%E0%A6%BF-%E0%A6%8F%E0%A6%AE-%E0%A6%8F%E0%A6%B2-%E0%A6%95%E0%A7%8B%E0%A6%B0%E0%A7%8D%E0%A6%B8-%E0%A6%B8%E0%A6%AE%E0%A7%82%E0%A6%B9-%E0%A5%A4-html-courses/

    }

}
